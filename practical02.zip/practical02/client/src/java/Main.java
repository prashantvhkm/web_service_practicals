/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author perfe
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println(add(23,3223));
        System.out.println(sub(23,3223));
        
    }

    private static Double add(double a, double b) {
        ws.Server_Service service = new ws.Server_Service();
        ws.Server port = service.getServerPort();
        return port.add(a, b);
    }

    private static Double sub(double a, double b) {
        ws.Server_Service service = new ws.Server_Service();
        ws.Server port = service.getServerPort();
        return port.sub(a, b);
    }
    
}
